const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const dataFilePath = path.join(__dirname, '../data/users.json');

// Ensure users.json exists
if (!fs.existsSync(dataFilePath)) {
  fs.writeFileSync(dataFilePath, JSON.stringify([]));
}

router.post('/', (req, res) => {
  const userData = req.body;
  if (!userData.name || !userData.email) {
    return res.status(400).json({ message: 'Missing name or email' });
  }

  const existingData = JSON.parse(fs.readFileSync(dataFilePath));
  existingData.push(userData);
  fs.writeFileSync(dataFilePath, JSON.stringify(existingData, null, 2));

  res.status(201).json({ message: 'Registration successful' });
});

module.exports = router;