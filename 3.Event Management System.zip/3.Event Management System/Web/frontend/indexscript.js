  function togglePassword() {
    const pwdInput = document.getElementById("password");
    const btn = document.querySelector(".toggle-btn");
    if (pwdInput.type === "password") {
      pwdInput.type = "text";
      btn.textContent = "Hide";
    } else {
      pwdInput.type = "password";
      btn.textContent = "Show";
    }
  }


  document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("registrationForm");
    if (!form) return;
  
    form.addEventListener("submit", function (e) {
      e.preventDefault();
  
      const name =
        form.querySelector('input[placeholder="First name *"]').value +
        " " +
        form.querySelector('input[placeholder="Last name *"]').value;
      const email = form.querySelector('input[placeholder=" Email *"]').value;
  
      fetch("http://localhost:5000/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, email })
      })
        .then((res) => res.json())
        .then((data) => {
          alert("✅ Registered successfully!");
          window.location.href = "Event.html";
        })
        .catch((err) => {
          alert("❌ Registration failed.");
          console.error(err);
        });
    });
  });
  
  window.location.href = "Event.html";
 

