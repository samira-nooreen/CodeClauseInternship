console.log("Navbar loaded.");
