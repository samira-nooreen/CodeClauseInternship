
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 8080;

app.use(cors());

app.get('/api/metrics', (req, res) => {
  res.json({
    steps: 7800,
    water: 2.5,
    calories: 1850,
    heartRate: 68,
    workoutsCompleted: 5,
    workoutsTotal: 10,
    mealsLogged: 4,
    mealsTotal: 6,
    sleepHours: 8
  });
});

app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}/api/metrics`);
});
