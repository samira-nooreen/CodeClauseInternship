const subscribeBtn = document.getElementById('subscribeBtn');

if (subscribeBtn) {
  subscribeBtn.addEventListener('click', () => {
    alert('Thank you for your interest in upgrading! This is a placeholder.');
  });
}

const stepsMetric = document.getElementById('stepsMetric');
let currentSteps = 7800; 

function updateSteps() {
  currentSteps += Math.floor(Math.random() * 100) + 50; 
  if (stepsMetric) {
    stepsMetric.textContent = currentSteps.toLocaleString(); 
  }

}


const workoutCompletedSpan = document.getElementById('workoutCompleted');
const workoutProgressBar = document.getElementById('workoutProgressBar');
const totalWorkouts = 10;

function updateWorkoutProgress(completed) {
  if (workoutCompletedSpan) {
    workoutCompletedSpan.textContent = completed;
  }
  if (workoutProgressBar) {
    const percentage = (completed / totalWorkouts) * 100;
    workoutProgressBar.style.width = `${percentage}%`;
  }
}

const monthlyData = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    datasets: [{
        label: 'Steps',
        data: [50000, 65000, 72000, 80000],
        backgroundColor: 'rgba(33, 150, 243, 0.6)', 
        borderColor: 'rgba(33, 150, 243, 1)',
        borderWidth: 1,
        fill: false 
    }]
};

const weeklyActivityData = {
    labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    datasets: [{
        label: 'Minutes Active',
        data: [30, 45, 60, 40, 55, 90, 70],
        backgroundColor: [
            'rgba(255, 99, 132, 0.6)', // Red
            'rgba(54, 162, 235, 0.6)', // Blue
            'rgba(255, 206, 86, 0.6)', // Yellow
            'rgba(75, 192, 192, 0.6)', // Green
            'rgba(153, 102, 255, 0.6)', // Purple
            'rgba(255, 159, 64, 0.6)', // Orange
            'rgba(199, 199, 199, 0.6)' // Grey
        ],
        borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)',
            'rgba(199, 199, 199, 1)'
        ],
        borderWidth: 1
    }]
};

const overallProgressData = {
    labels: ['Goals Completed', 'Goals In Progress', 'Goals Not Started'],
    datasets: [{
        data: [3, 2, 1], 
        backgroundColor: [
            'rgba(75, 192, 192, 0.6)', // Green
            'rgba(255, 159, 64, 0.6)', // Orange
            'rgba(255, 99, 132, 0.6)'  // Red
        ],
        borderColor: [
            'rgba(75, 192, 192, 1)',
            'rgba(255, 159, 64, 1)',
            'rgba(255, 99, 132, 1)'
        ],
        borderWidth: 1
    }]
};


function createChart(canvasId, type, data, options) {
  const ctx = document.getElementById(canvasId).getContext('2d');
  return new Chart(ctx, {
    type: type,
    data: data,
    options: options
  });
}


if (typeof Chart !== 'undefined') {
  const monthlyChart = createChart('monthlyPerformanceChart', 'line', monthlyData, {
      responsive: true, 
      maintainAspectRatio: false 
  });

  const weeklyChart = createChart('weeklyActivityChart', 'bar', weeklyActivityData, {
      responsive: true,
      maintainAspectRatio: false
  });

  const overallChart = createChart('overallProgressChart', 'pie', overallProgressData, {
      responsive: true,
      maintainAspectRatio: false
  });
} else {
  console.warn('Chart.js not found. Charts will not be rendered.');
}
